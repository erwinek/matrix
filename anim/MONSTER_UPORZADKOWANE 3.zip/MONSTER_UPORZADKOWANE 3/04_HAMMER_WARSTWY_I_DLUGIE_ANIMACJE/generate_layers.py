from pathlib import Path
from PIL import Image,ImageDraw,ImageSequence
import json,zipfile,shutil
root=Path('MONSTER_UPORZADKOWANE');folder=root/'04_HAMMER_WARSTWY_I_DLUGIE_ANIMACJE';folder.mkdir(exist_ok=True)
meta=json.loads((root/'INTEGRATION/animations.json').read_text()); records={}
def read(path):
 im=Image.open(path);return [f.copy() for f in ImageSequence.Iterator(im)]
def save(name,frames,durations=100,loop=None):
 path=folder/(name+'.gif');opts=dict(save_all=True,append_images=frames[1:],duration=durations,disposal=2,optimize=False)
 if loop is not None:opts['loop']=loop
 frames[0].save(path,**opts)
 check=Image.open(path);total=sum((check.seek(i) or check.info.get('duration',100)) for i in range(check.n_frames)); records[name]={'size':list(check.size),'frames':check.n_frames,'duration_ms':total,'loop':loop==0};return path
# Full-sized transparent overlays. Reuse each frame palette exactly.
for short,size,offset in [('A',(96,96),(3,27)),('B',(64,512),(1,149))]:
 im=Image.open(root/'03_TABLICE_WYNIKU_BEZ_TLA'/f'HAMMER_{short}_TABLICA_WYNIKU.gif');frames=[];durs=[]
 for i in range(im.n_frames):
  im.seek(i);rgba=im.convert('RGBA');colors=sorted(set(p[:3] for p in rgba.getdata() if p[3]));assert len(colors)<256
  lookup={c:i for i,c in enumerate(colors)};p=Image.new('P',rgba.size,255);p.putpalette([v for c in colors for v in c]+[0]*(768-3*len(colors)));p.putdata([lookup[c[:3]] if c[3] else 255 for c in rgba.getdata()]);canvas=Image.new('P',size,255);canvas.putpalette(p.getpalette());canvas.paste(p,offset);canvas.info['transparency']=255;frames.append(canvas);durs.append(im.info.get('duration',100))
 path=save(f'HAMMER_{short}_TABLICA_PRZEZROCZYSTA_{size[0]}x{size[1]}',frames,durs,0)
 test=Image.open(path)
 for i in range(test.n_frames):
  test.seek(i);a=test.convert('RGBA');assert a.getpixel((0,0))[3]==0
 records[path.stem]['board_position']=list(offset)
# Reconstruct the obscured board area from native Hammer beam artwork.
source=root/meta['HAMMER_RESULT_LOOP']['file'];result=read(source);hit=[f.convert('RGB') for f in read(root/meta['HAMMER_HIT_500']['file'])];frames=[]
for i,f in enumerate(result):
 im=f.convert('RGB');base=hit[28+i%16]
 # The clean upper beam contains no labels, head or score board.
 patch=base.crop((0,85,64,173));im.paste(patch,(0,149));frames.append(im)
save('HAMMER_RESULT_LOOP_BEZ_TABLICY_64x512',frames,100,0)
# Original destructive strikes followed by 8 s of the established end state.
for level in [100,200,300,400,500]:
 fs=[f.convert('RGB') for f in read(root/meta[f'HAMMER_HIT_{level}']['file'])];tail=fs[-16:];pingpong=tail+tail[-2:0:-1];extra=[pingpong[(15+i)%len(pingpong)] for i in range(80)]
 save(f'HAMMER_HIT_{level}_DESTRUKCJA_PLUS_8S',fs+extra)
 save(f'HAMMER_HIT_{level}_KONCOWKA_PETLA',pingpong,100,0)
# Also lengthen the four destructive tournament finales for independent use.
for ending in ['GOOD','GREAT','MONSTER','RECORD']:
 fs=[f.convert('RGB') for f in read(root/meta[f'T16_HAMMER_FINISH_{ending}']['file'])];tail=fs[-12:];pingpong=tail+tail[-2:0:-1];extra=[pingpong[(11+i)%len(pingpong)] for i in range(80)]
 save(f'HAMMER_FINAL_{ending}_PLUS_8S',fs+extra)
(folder/'PARAMETRY.json').write_text(json.dumps(records,indent=2))
(folder/'CZYTAJ.md').write_text('''# Hammer: tło wyniku, dłuższa destrukcja i osobne tablice

HAMMER_RESULT_LOOP_BEZ_TABLICY_64x512.gif — pętla wyniku bez ramki SCORE i jej czarnego pola. Zachowano postać, napis YOUR SCORE i pozostałą scenę; miejsce po tablicy odtworzono z oryginalnej grafiki świetlnego słupa Hammera.

HAMMER_A_TABLICA_PRZEZROCZYSTA_96x96.gif — płótno 96 × 96, tablica na pozycji (3,27).
HAMMER_B_TABLICA_PRZEZROCZYSTA_64x512.gif — płótno 64 × 512, tablica na pozycji (1,149).
Otoczenie jest przezroczyste, wnętrze tablicy pozostaje czarne. GIF-y nie zawierają cyfr. Pole cyfr na pełnym płótnie A: (11,40,74,31); B: (6,176,52,46). W folderze 03 pozostają małe, przycięte tablice do dowolnego pozycjonowania.

HAMMER_HIT_100/200/300/400/500_DESTRUKCJA_PLUS_8S.gif — pełna oryginalna destrukcja, następnie dodatkowe 8 s animowanej końcówki. Bez automatycznej pętli. Nie spowalniano samego uderzenia.
HAMMER_HIT_*_KONCOWKA_PETLA.gif — osobna pętla końcowego stanu do wyświetlania wyniku przez dowolny czas.
HAMMER_FINAL_GOOD/GREAT/MONSTER/RECORD_PLUS_8S.gif — dodatkowo wydłużone finały turniejowe: 4,8 s + 8 s = 12,8 s, bez automatycznej pętli.

W sterowniku: odtwórz destrukcję, następnie pętlę końcówki albo RESULT_LOOP_BEZ_TABLICY; na osobnej warstwie uruchom wybraną tablicę oraz cyfry. Nie zapętlaj całej destrukcji. Dłuższy plik pokazuje końcowy stan przez dodatkowe 8 s; osobna pętla pozwala wydłużać go bez ograniczenia.

PODGLAD.html pozwala sprawdzić osobne warstwy, wybrać animację tła, zmienić wynik i przesunąć tablicę.
Nowe pliki są wariantami do integracji. Oryginalny PREVIEW/PREVIEW.html i jego sekwencja pozostają zachowane.
''')
html='''<!doctype html><meta charset="utf-8"><title>Hammer — warstwy wyniku</title><style>body{background:#202b3b;color:white;font:17px system-ui;padding:25px}select,input,button{font:inherit;margin:8px;padding:8px}#stage{width:128px;height:1024px;position:relative;background:#000;margin:20px}#bg{width:100%;height:100%;image-rendering:pixelated}.board{position:absolute;width:124px;height:176px;left:2px;top:298px;cursor:move;touch-action:none}.board img{width:100%;height:100%;image-rendering:pixelated}.score{position:absolute;left:10px;top:54px;width:104px;height:92px;display:flex;align-items:center;justify-content:center;font:bold 28px monospace;color:#ffe81a}</style><h1>Hammer — tło i tablica osobno</h1><p>Przeciągnij tablicę w inne miejsce. Wynik jest osobną warstwą. Skala podglądu 2×.</p><select id="choice"></select><input id="value" type="number" value="480" min="0" max="9999"><button id="toggle">Ukryj / pokaż tablicę</button><button id="restart">Odtwórz ponownie</button><div id="stage"><img id="bg"><div class="board" id="board"><img src="../03_TABLICE_WYNIKU_BEZ_TLA/HAMMER_B_TABLICA_WYNIKU.gif"><div class="score" id="score">480</div></div></div><script>const names=__NAMES__;const choice=document.getElementById('choice'),bg=document.getElementById('bg'),board=document.getElementById('board');for(let n of names){let o=document.createElement('option');o.value=n;o.textContent=n;choice.append(o)}function start(){bg.src=choice.value+'.gif?'+Date.now()}choice.onchange=start;restart.onclick=start;start();document.getElementById('value').oninput=e=>score.textContent=Math.max(0,Math.min(9999,Number(e.target.value)||0));toggle.onclick=()=>board.hidden=!board.hidden;board.onpointerdown=e=>{board.setPointerCapture(e.pointerId);let ox=e.clientX-board.offsetLeft,oy=e.clientY-board.offsetTop;board.onpointermove=e=>{board.style.left=(e.clientX-ox)+'px';board.style.top=(e.clientY-oy)+'px'};board.onpointerup=()=>board.onpointermove=null};</script>'''
names=[n for n in records if 'TABLICA_PRZEZROCZYSTA' not in n];(folder/'PODGLAD.html').write_text(html.replace('__NAMES__',json.dumps(names)))
p=root/'CZYTAJ_NAJPIERW.md';s=p.read_text();s=s.split('\n## Warstwy wyniku i wydłużone animacje')[0];s+='\n## Warstwy wyniku i wydłużone animacje\nFolder 04_HAMMER_WARSTWY_I_DLUGIE_ANIMACJE: wynik bez tablicy, tablice 96×96 i 64×512, destrukcje i finały wydłużone o 8 s, osobne pętle końcówek oraz podgląd warstw.\n';p.write_text(s)
shutil.copy2(__file__,folder/'generate_layers.py')
with zipfile.ZipFile('MONSTER_HAMMER_WARSTWY.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(root.rglob('*')):
  if p.is_file():z.write(p,p.as_posix())
with zipfile.ZipFile('MONSTER_HAMMER_WARSTWY.zip') as z:assert z.testzip() is None
print(json.dumps(records));print('ZIP',Path('MONSTER_HAMMER_WARSTWY.zip').stat().st_size)
